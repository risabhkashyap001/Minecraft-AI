package com.creeperheal.enhanced;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Container;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class ExplosionListener implements Listener {
    
    private final EnhancedCreeperHeal plugin;
    private final RestorationManager restorationManager;
    
    public ExplosionListener(EnhancedCreeperHeal plugin, RestorationManager restorationManager) {
        this.plugin = plugin;
        this.restorationManager = restorationManager;
    }
    
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onExplosion(EntityExplodeEvent event) {
        Entity entity = event.getEntity();
        String worldName = event.getLocation().getWorld().getName();
        
        if (!isWorldEnabled(worldName)) {
            return;
        }
        
        if (!isExplosionTypeEnabled(entity)) {
            return;
        }
        
        List<Block> blocks = event.blockList();
        if (blocks.isEmpty()) {
            return;
        }
        
        int maxBlocks = plugin.getConfig().getInt("settings.max-blocks-per-explosion", 500);
        if (blocks.size() > maxBlocks) {
            plugin.getLogger().warning("Explosion too large (" + blocks.size() + " blocks), skipping restoration");
            return;
        }
        
        List<BlockData> blockDataList = new ArrayList<>();
        boolean restoreContainers = plugin.getConfig().getBoolean("settings.restore-containers", true);
        
        for (Block block : blocks) {
            if (block.getType() == Material.AIR) {
                continue;
            }
            
            ItemStack[] containerSnapshot = null;
            BlockState state = block.getState();
            
            if (state instanceof Container container) {
                if (restoreContainers) {
                    containerSnapshot = container.getInventory().getContents().clone();
                }
                container.getInventory().clear();
                state.update(true, false);
                state = block.getState();
            }
            
            BlockData blockData = new BlockData(
                block.getLocation().clone(),
                state,
                containerSnapshot
            );
            blockDataList.add(blockData);
        }
        
        if (!blockDataList.isEmpty()) {
            event.setYield(0);
            
            if (plugin.getConfig().getBoolean("settings.debug", false)) {
                plugin.getLogger().info("Captured " + blockDataList.size() + " blocks from " + 
                    getExplosionTypeName(entity) + " explosion at " + 
                    formatLocation(event.getLocation()));
            }
            
            restorationManager.scheduleRestoration(blockDataList);
        }
    }
    
    private boolean isWorldEnabled(String worldName) {
        List<String> enabledWorlds = plugin.getConfig().getStringList("worlds.enabled-worlds");
        boolean blacklistMode = plugin.getConfig().getBoolean("worlds.blacklist-mode", false);
        
        if (enabledWorlds.isEmpty()) {
            return true;
        }
        
        boolean inList = enabledWorlds.contains(worldName);
        return blacklistMode ? !inList : inList;
    }
    
    private boolean isExplosionTypeEnabled(Entity entity) {
        if (entity instanceof Creeper) {
            return plugin.getConfig().getBoolean("explosions.creeper", true);
        } else if (entity instanceof TNTPrimed) {
            return plugin.getConfig().getBoolean("explosions.tnt", true);
        } else if (entity instanceof Ghast || entity instanceof LargeFireball) {
            return plugin.getConfig().getBoolean("explosions.ghast", true);
        } else if (entity instanceof Wither || entity instanceof WitherSkull) {
            return plugin.getConfig().getBoolean("explosions.wither", true);
        } else if (entity instanceof EnderCrystal) {
            return plugin.getConfig().getBoolean("explosions.ender-crystal", true);
        }
        
        return true;
    }
    
    private String getExplosionTypeName(Entity entity) {
        if (entity instanceof Creeper) return "Creeper";
        if (entity instanceof TNTPrimed) return "TNT";
        if (entity instanceof Ghast) return "Ghast";
        if (entity instanceof Wither) return "Wither";
        if (entity instanceof EnderCrystal) return "Ender Crystal";
        return "Unknown";
    }
    
    private String formatLocation(Location loc) {
        return String.format("%s @ %d, %d, %d",
            loc.getWorld().getName(),
            loc.getBlockX(),
            loc.getBlockY(),
            loc.getBlockZ()
        );
    }
}
