package com.creeperheal.enhanced;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class EnhancedCreeperHeal extends JavaPlugin {
    
    private RestorationManager restorationManager;
    private ExplosionListener explosionListener;
    
    @Override
    public void onEnable() {
        saveDefaultConfig();
        
        restorationManager = new RestorationManager(this);
        explosionListener = new ExplosionListener(this, restorationManager);
        
        getServer().getPluginManager().registerEvents(explosionListener, this);
        
        getLogger().info("EnhancedCreeperHeal v" + getDescription().getVersion() + " has been enabled!");
        getLogger().info("Explosion healing is now active with gradual restoration");
        
        if (getServer().getPluginManager().getPlugin("floodgate") != null) {
            getLogger().info("Floodgate detected - Bedrock players supported!");
        }
        if (getServer().getPluginManager().getPlugin("Geyser-Spigot") != null) {
            getLogger().info("Geyser detected - Cross-platform support enabled!");
        }
    }
    
    @Override
    public void onDisable() {
        if (restorationManager != null) {
            restorationManager.shutdown();
        }
        
        getLogger().info("EnhancedCreeperHeal has been disabled!");
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("creeperheal")) {
            return false;
        }
        
        if (!sender.hasPermission("creeperheal.admin")) {
            sender.sendMessage("§cYou don't have permission to use this command!");
            return true;
        }
        
        if (args.length == 0) {
            sender.sendMessage("§e§lEnhancedCreeperHeal §7v" + getDescription().getVersion());
            sender.sendMessage("§7Commands:");
            sender.sendMessage("§e/creeperheal reload §7- Reload configuration");
            sender.sendMessage("§e/creeperheal cancel §7- Cancel all pending restorations");
            sender.sendMessage("§e/creeperheal info §7- Show plugin information");
            return true;
        }
        
        switch (args[0].toLowerCase()) {
            case "reload":
                reloadConfig();
                restorationManager.reloadSettings();
                sender.sendMessage("§aConfiguration reloaded successfully!");
                return true;
                
            case "cancel":
                int cancelled = restorationManager.cancelAll();
                sender.sendMessage("§aCancelled §e" + cancelled + " §apending restoration(s)!");
                return true;
                
            case "info":
                int pending = restorationManager.getPendingCount();
                sender.sendMessage("§e§lEnhancedCreeperHeal Information");
                sender.sendMessage("§7Version: §e" + getDescription().getVersion());
                sender.sendMessage("§7Pending Restorations: §e" + pending);
                sender.sendMessage("§7Block Interval: §e" + getConfig().getInt("block-interval") + " ticks");
                sender.sendMessage("§7Restoration Delay: §e" + getConfig().getInt("restoration-delay") + " seconds");
                return true;
                
            default:
                sender.sendMessage("§cUnknown subcommand! Use /creeperheal for help.");
                return true;
        }
    }
    
    public RestorationManager getRestorationManager() {
        return restorationManager;
    }
}
