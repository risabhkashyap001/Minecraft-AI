package com.creeperheal.enhanced;

import org.bukkit.Location;
import org.bukkit.block.BlockState;
import org.bukkit.inventory.ItemStack;

public class BlockData {
    
    private final Location location;
    private final BlockState blockState;
    private final ItemStack[] containerSnapshot;
    
    public BlockData(Location location, BlockState blockState, ItemStack[] containerSnapshot) {
        this.location = location;
        this.blockState = blockState;
        this.containerSnapshot = containerSnapshot;
    }
    
    public Location getLocation() {
        return location;
    }
    
    public BlockState getBlockState() {
        return blockState;
    }
    
    public ItemStack[] getContainerSnapshot() {
        return containerSnapshot;
    }
    
    public boolean hasContainerSnapshot() {
        return containerSnapshot != null;
    }
}
