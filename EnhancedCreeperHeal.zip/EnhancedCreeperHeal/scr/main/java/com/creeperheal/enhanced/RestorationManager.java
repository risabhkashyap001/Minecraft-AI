package com.creeperheal.enhanced;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Container;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class RestorationManager {
    
    private final EnhancedCreeperHeal plugin;
    private final Map<UUID, BukkitTask> activeTasks;
    private int restorationDelay;
    private int blockInterval;
    private boolean particlesEnabled;
    private boolean soundsEnabled;
    private boolean randomOrder;
    
    public RestorationManager(EnhancedCreeperHeal plugin) {
        this.plugin = plugin;
        this.activeTasks = new ConcurrentHashMap<>();
        reloadSettings();
    }
    
    public void reloadSettings() {
        this.restorationDelay = plugin.getConfig().getInt("restoration-delay", 3);
        this.blockInterval = plugin.getConfig().getInt("block-interval", 4);
        this.particlesEnabled = plugin.getConfig().getBoolean("particles-enabled", true);
        this.soundsEnabled = plugin.getConfig().getBoolean("sounds-enabled", true);
        this.randomOrder = plugin.getConfig().getBoolean("settings.random-order", true);
    }
    
    public void scheduleRestoration(List<BlockData> blockDataList) {
        if (blockDataList == null || blockDataList.isEmpty()) {
            return;
        }
        
        List<BlockData> blocksToRestore = new ArrayList<>(blockDataList);
        
        if (randomOrder) {
            Collections.shuffle(blocksToRestore);
        }
        
        UUID taskId = UUID.randomUUID();
        
        BukkitTask task = new BukkitRunnable() {
            @Override
            public void run() {
                startGradualRestoration(taskId, blocksToRestore);
            }
        }.runTaskLater(plugin, restorationDelay * 20L);
        
        activeTasks.put(taskId, task);
    }
    
    private void startGradualRestoration(UUID taskId, List<BlockData> blockDataList) {
        activeTasks.remove(taskId);
        
        BukkitTask restorationTask = new BukkitRunnable() {
            private int index = 0;
            
            @Override
            public void run() {
                if (index >= blockDataList.size()) {
                    this.cancel();
                    activeTasks.remove(taskId);
                    
                    if (plugin.getConfig().getBoolean("settings.debug", false)) {
                        plugin.getLogger().info("Completed restoration of " + blockDataList.size() + " blocks");
                    }
                    return;
                }
                
                BlockData blockData = blockDataList.get(index);
                restoreBlock(blockData);
                index++;
            }
        }.runTaskTimer(plugin, 0L, blockInterval);
        
        activeTasks.put(taskId, restorationTask);
    }
    
    private void restoreBlock(BlockData blockData) {
        Location location = blockData.getLocation();
        Block block = location.getBlock();
        
        if (block.getType() != Material.AIR) {
            return;
        }
        
        BlockState savedState = blockData.getBlockState();
        savedState.update(true, false);
        
        if (blockData.hasContainerSnapshot()) {
            BlockState newState = block.getState();
            if (newState instanceof Container container) {
                container.getInventory().setContents(blockData.getContainerSnapshot());
                newState.update(true);
            }
        }
        
        if (particlesEnabled) {
            location.getWorld().spawnParticle(
                Particle.VILLAGER_HAPPY,
                location.clone().add(0.5, 0.5, 0.5),
                5,
                0.3, 0.3, 0.3,
                0
            );
        }
        
        if (soundsEnabled) {
            location.getWorld().playSound(
                location,
                Sound.BLOCK_STONE_PLACE,
                0.5f,
                1.2f
            );
        }
    }
    
    public int cancelAll() {
        int count = 0;
        for (BukkitTask task : activeTasks.values()) {
            task.cancel();
            count++;
        }
        activeTasks.clear();
        return count;
    }
    
    public int getPendingCount() {
        return activeTasks.size();
    }
    
    public void shutdown() {
        cancelAll();
    }
}
