import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;

public class BuildInfo {
    public static void main(String[] args) throws Exception {
        System.out.println("=".repeat(60));
        System.out.println("    ENHANCED CREEPERHEAL PLUGIN - BUILD STATUS");
        System.out.println("=".repeat(60));
        System.out.println();
        
        File jarFile = new File("target/EnhancedCreeperHeal-1.0.0.jar");
        
        if (jarFile.exists()) {
            long fileSize = jarFile.length();
            String lastModified = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
                .format(new Date(jarFile.lastModified()));
            
            System.out.println("✓ Plugin JAR Built Successfully!");
            System.out.println();
            System.out.println("  File: " + jarFile.getName());
            System.out.println("  Size: " + (fileSize / 1024) + " KB");
            System.out.println("  Built: " + lastModified);
            System.out.println("  Location: " + jarFile.getAbsolutePath());
            System.out.println();
            System.out.println("=".repeat(60));
            System.out.println("    INSTALLATION INSTRUCTIONS");
            System.out.println("=".repeat(60));
            System.out.println();
            System.out.println("1. Download the JAR file from: target/EnhancedCreeperHeal-1.0.0.jar");
            System.out.println("2. Upload it to your Minecraft server's /plugins/ folder");
            System.out.println("3. Restart your server or use /reload");
            System.out.println("4. Configure settings in /plugins/EnhancedCreeperHeal/config.yml");
            System.out.println();
            System.out.println("=".repeat(60));
            System.out.println("    FEATURES");
            System.out.println("=".repeat(60));
            System.out.println();
            System.out.println("• Explosion craters stay visible for configurable delay");
            System.out.println("• Blocks heal gradually one by one");
            System.out.println("• Particle effects and sounds during restoration");
            System.out.println("• Supports Creeper, TNT, Ghast, Wither explosions");
            System.out.println("• Compatible with GeyserMC and Floodgate");
            System.out.println("• Fully configurable timing and effects");
            System.out.println();
            System.out.println("=".repeat(60));
            System.out.println("    COMMANDS");
            System.out.println("=".repeat(60));
            System.out.println();
            System.out.println("/creeperheal reload  - Reload configuration");
            System.out.println("/creeperheal cancel  - Cancel pending restorations");
            System.out.println("/creeperheal info    - Show plugin information");
            System.out.println();
            System.out.println("=".repeat(60));
            System.out.println();
            System.out.println("Your plugin is ready to upload to minefort.com!");
            System.out.println();
        } else {
            System.out.println("✗ Plugin JAR not found!");
            System.out.println();
            System.out.println("Run 'mvn clean package' to build the plugin.");
            System.out.println();
        }
    }
}
